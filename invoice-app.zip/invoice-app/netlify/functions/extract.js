exports.handler = async function (event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  const ANTHROPIC_KEY = process.env.ANTHROPIC_API_KEY;
  if (!ANTHROPIC_KEY) {
    return { statusCode: 500, body: JSON.stringify({ error: "API key not configured" }) };
  }

  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid request body" }) };
  }

  const { type, content } = body;
  // type: "text" | "image"
  // content: string (text) or { base64, mediaType } (image)

  const userContent =
    type === "image"
      ? [
          {
            type: "image",
            source: {
              type: "base64",
              media_type: content.mediaType,
              data: content.base64,
            },
          },
          {
            type: "text",
            text: buildPrompt(),
          },
        ]
      : buildPrompt() + "\n\nINVOICE TEXT:\n" + content;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": ANTHROPIC_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 1024,
        messages: [
          {
            role: "user",
            content: userContent,
          },
        ],
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      return {
        statusCode: response.status,
        body: JSON.stringify({ error: data?.error?.message || "Anthropic API error" }),
      };
    }

    const text = data.content?.[0]?.text || "";

    // Parse JSON from Claude's response
    let parsed;
    try {
      const clean = text.replace(/```json|```/gi, "").trim();
      parsed = JSON.parse(clean);
    } catch {
      const match = text.match(/\{[\s\S]*\}/);
      if (match) {
        try { parsed = JSON.parse(match[0]); }
        catch { return { statusCode: 200, body: JSON.stringify({ raw: text }) }; }
      } else {
        return { statusCode: 200, body: JSON.stringify({ raw: text }) };
      }
    }

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ data: parsed }),
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message || "Server error" }),
    };
  }
};

function buildPrompt() {
  return `You are an invoice data extraction system. Extract ALL fields from this invoice and return ONLY a valid JSON object with exactly these keys (use null if missing):

{
  "supplier_name": string or null,
  "invoice_number": string or null,
  "invoice_date": string or null,
  "due_date": string or null,
  "currency": string or null,
  "subtotal": number or null,
  "tax_amount": number or null,
  "total_amount": number or null,
  "payment_terms": string or null,
  "bill_to": string or null,
  "line_items": [
    {
      "description": string,
      "quantity": number or null,
      "unit_price": number or null,
      "total": number or null
    }
  ]
}

Return ONLY the JSON. No explanation, no markdown fences. Raw JSON only.`;
}
